This project source helps you to build your own blockchin APIs

Requirements

Java 8.0 or greater
Maven 3.*

Implementation

Go to the project directory in cmd

Execute the command "mvn spring-boot:run"

In your favourite browser execute /addBlock


Using Postman

check the following calls

1. GET - localhost:8080/addBlock
2. GET - localhost:8080/createWallet
3. GET - localhost:8080/checkGenerateSignature
4. GET - localhost:8080/checkVerifySignature

