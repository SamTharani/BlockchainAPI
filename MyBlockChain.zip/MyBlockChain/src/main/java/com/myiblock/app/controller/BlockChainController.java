package com.myiblock.app.controller;


import com.google.gson.GsonBuilder;
import com.myiblock.app.model.*;
import com.myiblock.app.utils.SignatureUtil;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.Security;
import java.util.ArrayList;
import java.util.HashMap;

@RestController
public class BlockChainController {

    private static ArrayList<Block> blockChain = new ArrayList<Block>();
    private static int difficulty = 5;

    public static Wallet walletA;
    public static Wallet walletB;
    public static BlockChain coin;
    public static Transaction genesisTransaction;


    @RequestMapping("/addBlock")
    public String addBlock(){

        blockChain.add(new Block("0","I am block 1"));
        System.out.print("Mining Block 1");
        blockChain.get(0).mineBlock(difficulty);

        blockChain.add(new Block(blockChain.get(0).hash,"I am block 2"));
        System.out.println("Mining Block 2");
        blockChain.get(1).mineBlock(difficulty);

        blockChain.add(new Block(blockChain.get(1).hash, "I am block 3"));
        System.out.println("Mining Block 3");
        blockChain.get(2).mineBlock(difficulty);

        System.out.println("Blockchain is valid "+isValid());
        System.out.println("My Blockchain is: ");

        return new GsonBuilder().setPrettyPrinting().create().toJson(blockChain);

    }

    @RequestMapping("/createWallet")
    public void generateWallet(){

        //add our blocks to the blockchain ArrayList:
        Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider()); //Setup Bouncey castle as a Security Provider

        walletA = new Wallet();

        System.out.println("Wallet A privateKey: "+walletA.privateKey);
        System.out.println("Wallet A publicKey: "+walletA.publicKey);

        walletB = new Wallet();
        System.out.println("Wallet B privateKey: "+walletB.privateKey);
        System.out.println("Wallet B publicKey: "+walletB.publicKey);

        Wallet coinBase = new Wallet();
        coin = new BlockChain();
        genesisTransaction = coin.createGenesisTransaction(coinBase,walletA,100f);
        //its important to store our first transaction in the UTXOs list.

        System.out.println("Creating and Mining Genesis Block ...");

        Block genesis = new Block("0");
        genesis.addTransaction(genesisTransaction);
        addBlock(genesis);

        //Testing
        Block block1 = new Block(genesis.hash);
        System.out.println("\nWalletA's balance is: " + walletA.getBalance());
        System.out.println("\nWalletA is Attempting to send funds (40) to WalletB...");
        block1.addTransaction(walletA.sendFunds(walletB.publicKey, 40f));
        addBlock(block1);
        System.out.println("\nWalletA's balance is: " + walletA.getBalance());
        System.out.println("WalletB's balance is: " + walletB.getBalance());

    }

    @RequestMapping("/checkGenerateSignature")
    public byte [] checkGenerateSignature(){
        Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider()); //Setup Bouncey castle as a Security Provider

        walletA = new Wallet();
        walletB = new Wallet();

        // Private and public key of walletA
        System.out.println("Public key of the waletA: "+ SignatureUtil.getStringFromKey(walletA.publicKey));
        System.out.println("Private key of the waletA: "+ SignatureUtil.getStringFromKey(walletA.privateKey));

        // Transaction from walletA to walletB
        Transaction transaction = new Transaction(walletA.publicKey,walletB.publicKey,5,null);
        transaction.generateSignature(walletA.privateKey);

        return transaction.signature;
    }

    @RequestMapping("/checkVerifySignature")
    public boolean verifySignature(){
        Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider()); //Setup Bouncey castle as a Security Provider

        walletA = new Wallet();
        walletB = new Wallet();

        Transaction transaction = new Transaction(walletA.publicKey,walletB.publicKey,5,null);
        transaction.generateSignature(walletA.privateKey);

       return transaction.verifySignature();

    }

    public static void addBlock(Block newBlock) {
        newBlock.mineBlock(difficulty);
        blockChain.add(newBlock);
    }


    private static boolean isValid()
    {
        String hashTarget = new String(new char[difficulty]).replace('\0', '0');
        HashMap<String,TransactionOutput> tempUTXOs = new HashMap<String,TransactionOutput>(); //a temporary working list of unspent transactions at a given block state.
        //Check hashes of the block
        for(int i=1;i<blockChain.size();i++)
        {
            if(!(blockChain.get(i).hash.equals(blockChain.get(i).calculateHash()))){
                System.out.println("Current Hashes not equal");
                return false;
            }

            if(!(blockChain.get(i).previousHash.equals(blockChain.get(i-1).hash)))
            {
                System.out.println("Previous Hashes not equal");
                return false;
            }
            //Check if block is mined
            if(!blockChain.get(i).hash.substring(0,difficulty).equals(hashTarget))
            {
                System.out.println("This block has not been mined");
            }

            //loop thru blockchains transactions:
            TransactionOutput tempOutput;
            for(int t=0; t <blockChain.get(i).transactions.size(); t++) {
                Transaction currentTransaction = blockChain.get(i).transactions.get(t);

                if(!currentTransaction.verifySignature()) {
                    System.out.println("#Signature on Transaction(" + t + ") is Invalid");
                    return false;
                }
                if(currentTransaction.getInputValue() != currentTransaction.getOutputsValue()) {
                    System.out.println("#Inputs are note equal to outputs on Transaction(" + t + ")");
                    return false;
                }

                for(TransactionInput input: currentTransaction.inputs) {
                    tempOutput = tempUTXOs.get(input.transactionOutputId);

                    if(tempOutput == null) {
                        System.out.println("#Referenced input on Transaction(" + t + ") is Missing");
                        return false;
                    }

                    if(input.UTXO.value != tempOutput.value) {
                        System.out.println("#Referenced input Transaction(" + t + ") value is Invalid");
                        return false;
                    }

                    tempUTXOs.remove(input.transactionOutputId);
                }

                for(TransactionOutput output: currentTransaction.outputs) {
                    tempUTXOs.put(output.id, output);
                }

                if( currentTransaction.outputs.get(0).receiver != currentTransaction.receiver) {
                    System.out.println("#Transaction(" + t + ") output reciepient is not who it should be");
                    return false;
                }
                if( currentTransaction.outputs.get(1).receiver != currentTransaction.sender) {
                    System.out.println("#Transaction(" + t + ") output 'change' is not sender.");
                    return false;
                }

            }

        }
        System.out.println("Blockchain is valid");
        return  true;
    }


}
