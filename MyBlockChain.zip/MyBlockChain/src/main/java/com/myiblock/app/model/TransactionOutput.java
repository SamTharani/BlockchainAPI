package com.myiblock.app.model;

import java.security.PublicKey;

public class TransactionOutput {

    public String id;
    public PublicKey receiver; //also known as the new owner of these coins.
    public float value; //the amount of coins they own
    public String parentTransactionId; //the id of the transaction this output was created in

    public TransactionOutput(PublicKey receiver, float value, String parentTransactionId) {
        this.receiver = receiver;
        this.value = value;
        this.parentTransactionId = parentTransactionId;
    }

    //Check if coin belongs to you
    public boolean isMine(PublicKey publicKey){
        return (publicKey == receiver);
    }
}
