package com.myiblock.app.model;

import java.security.Security;
import java.util.ArrayList;
import java.util.HashMap;

public class BlockChain {

    public static Transaction genesisTransaction;
    public static HashMap<String,TransactionOutput> UTXOs = new HashMap<String,TransactionOutput>();
    public static float minimumTransaction = 0.1f;

    public Transaction createGenesisTransaction(Wallet coinBase,Wallet wallet, float value){

        //create genesis transaction, which sends 100 NoobCoin to walletA:
        genesisTransaction = new Transaction(coinBase.publicKey,wallet.publicKey,value,null);

        genesisTransaction.generateSignature(coinBase.privateKey); //Generate signature for transaction
        genesisTransaction.transactionId = "0"; //manually set the transaction id
        genesisTransaction.outputs.add(new TransactionOutput(genesisTransaction.receiver,genesisTransaction.value,
                                      genesisTransaction.transactionId));
        UTXOs.put(genesisTransaction.outputs.get(0).id,genesisTransaction.outputs.get(0));//its important to store our first transaction in the UTXOs list.

        return genesisTransaction;

    }


}
